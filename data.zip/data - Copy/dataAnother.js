export const anotherFood = [
    {
        id: 1,
        name: 'Sashimi set',
        image: 'https://ichibansushi.co.id/wp-content/uploads/2023/07/SASHIMI-SET_NEW-03.jpg',
        description: 'Chicken Curry',
        category: 'chicken',
        price: 1000
    },

    {
        id: 2,
        name: 'Salmon Sashimi',
        image: 'https://ichibansushi.co.id/wp-content/uploads/2023/07/SALMON-SASHIMI-1.jpg',
        description: 'Salmon Sashimi',
        category: 'salmon',
        price: 1000
    },
    
    {
        id: 3,
        name: 'Tuna Nigiri Sushi',
        image: 'https://ichibansushi.co.id/wp-content/uploads/2023/07/SPICY-TUNA-ROLL-1.jpg',
        description: 'Chicken Curry',
        category: 'tuna',
        price: 1000
    },

    {
        id: 4,
        name: 'Tamago Mentai Sushi',
        image: 'https://ichibansushi.co.id/wp-content/uploads/2024/05/TAMAGO-MENTAI-SUSHI.jpg',
        description: 'Chicken',
        category: 'chicken',
        price: 1000
    },

    {
        id: 5,
        name: 'Chicken Katsu Toji Donburi',
        image: 'https://ichibansushi.co.id/wp-content/uploads/2024/05/CHICKEN-KATSU-TOJI-DONBURI.jpg',
        description: 'Chicken Katsu with Donburi',
        category: 'chicken',
        price: 1000
    },

    
]
