export const foodList= [
    {
        id: 1,
        name: 'Mentai Sushi',
        image: 'https://ichibansushi.co.id/wp-content/uploads/2023/07/ROASTED-SALMON-SUSHII.jpg',
        description: 'Roasted Salmon Sushi',
        category: 'salmon',
        price: 1000
    },
    {
        id: 2,
        name: 'Karage',
        image: 'https://img.foodspot.co.id/restaurant//yoshinoya/chicken-karaage.jpg',
        description: 'Chicken Karage',
        category: 'chicken',
        price: 1000
    },

    {
        id: 3,
        name: 'Ramen',
        image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSLvjJMBycF8yPHWCLby-5d1vjJo9Q6zpnMog&s',
        description: 'Spicy Ramen',
        category: 'noodles',
        price: 1000
    },

    {
        id: 4,
        name: 'Tempura',
        image: 'https://ichibansushi.co.id/wp-content/uploads/2023/06/EBI-TEMPURA-1.jpg',
        description: 'Tempura',
        category: 'shrimp',
        price: 1000
    },

    {
        id: 5,
        name: 'Chicken Curry',
        image: 'https://ichibansushi.co.id/wp-content/uploads/2023/07/CHICKEN-KATSU-CURRY-DONBURI-1.jpg',
        description: '',
        category: 'chicken',
        price: 1000
    },

    {
        id: 6,
        name: 'Sashimi set',
        image: 'https://ichibansushi.co.id/wp-content/uploads/2023/07/SASHIMI-SET_NEW-03.jpg',
        description: 'Chicken Curry',
        category: 'chicken',
        price: 1000
    },

    {
        id: 7,
        name: 'Salmon Sashimi',
        image: 'https://ichibansushi.co.id/wp-content/uploads/2023/07/SALMON-SASHIMI-1.jpg',
        description: 'Salmon Sashimi',
        category: 'salmon',
        price: 1000
    },
    
    {
        id: 8,
        name: 'Tuna Nigiri Sushi',
        image: 'https://ichibansushi.co.id/wp-content/uploads/2023/07/SPICY-TUNA-ROLL-1.jpg',
        description: 'Chicken Curry',
        category: 'tuna',
        price: 1000
    },

    {
        id: 9,
        name: 'Tamago Mentai Sushi',
        image: 'https://ichibansushi.co.id/wp-content/uploads/2024/05/TAMAGO-MENTAI-SUSHI.jpg',
        description: 'Chicken',
        category: 'chicken',
        price: 1000
    },

    {
        id: 10,
        name: 'Chicken Katsu Toji Donburi',
        image: 'https://ichibansushi.co.id/wp-content/uploads/2024/05/CHICKEN-KATSU-TOJI-DONBURI.jpg',
        description: 'Chicken Katsu with Donburi',
        category: 'chicken',
        price: 1000
    },

]